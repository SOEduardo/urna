﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UrnaJCerto
{
    public partial class FormResultado : Form
    {
        double porcentCarlos, porcentDimitri, porcentGabriel, porcentGustavo, total;
        FormVotos votos;

        public FormResultado(FormVotos votos)
        {
            InitializeComponent();
            this.votos = votos;          
            Porcentagem();
            if(this.total > 0)
            {
                label6.Text = string.Format("{0:P2}", porcentCarlos);
                lbl_Dimitri.Text = string.Format("{0:P2}", porcentDimitri);
                lbl_Gabriel.Text = string.Format("{0:P2}", porcentGabriel);
                lbl_Gustavo.Text = string.Format("{0:P2}", porcentGustavo);
            } else
            {
                label6.Text = "0%";
                lbl_Dimitri.Text = "0%";
                lbl_Gabriel.Text = "0%";
                lbl_Gustavo.Text = "0%";
            }
            lbl_Dimitri.Parent = gradientPanel1;
            lbl_Gabriel.Parent = gradientPanel1;
            lbl_Gustavo.Parent = gradientPanel1;
            label1.Parent = gradientPanel1;
            label2.Parent = gradientPanel1;
            label3.Parent = gradientPanel1;
            label4.Parent = gradientPanel1;
            label5.Parent = gradientPanel1;
            label6.Parent = gradientPanel1;
        }

        public void Porcentagem()
        {
            this.total = votos.pontosCarlos + votos.pontosDimitri + votos.pontosGabriel + votos.pontosGustavo;
            porcentCarlos = votos.pontosCarlos / total;
            porcentDimitri = votos.pontosDimitri / total;
            porcentGabriel = votos.pontosGabriel / total;
            porcentGustavo = votos.pontosGustavo / total;
        }
    }
}
